// scripts.js

// Afficher une alerte de confirmation lors de l'envoi du formulaire
document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
  
    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault(); // Empêche l'envoi automatique pour la démo
        const confirmSubmit = confirm("Voulez-vous vraiment enregistrer ce dossier ?");
        
        if (confirmSubmit) {
          // Ici, normalement, tu enverrais le formulaire avec AJAX ou tu supprimerais e.preventDefault()
          alert("Dossier enregistré avec succès !");
          form.submit(); // Pour un envoi réel, enlève e.preventDefault() ou utilise cette ligne
        }
      });
    }
  });
  
  // Animation douce sur les liens de la navbar
  const navbarLinks = document.querySelectorAll('.nav-link');
  
  navbarLinks.forEach(link => {
    link.addEventListener('mouseover', () => {
      link.style.color = "#0d47a1";
    });
    link.addEventListener('mouseout', () => {
      link.style.color = "";
    });
  });
  